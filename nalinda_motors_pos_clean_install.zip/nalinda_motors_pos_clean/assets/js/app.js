document.addEventListener('DOMContentLoaded',()=>{const el=document.querySelector('[autofocus]'); if(el) el.focus();});
function confirmDelete(){return confirm('Are you sure?');}
