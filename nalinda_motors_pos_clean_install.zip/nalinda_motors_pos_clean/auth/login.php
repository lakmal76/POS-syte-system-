<?php
session_start(); require_once __DIR__.'/../includes/db.php'; require_once __DIR__.'/../includes/helpers.php';
if (isset($_SESSION['user'])) app_redirect('/index.php');
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $stmt=$pdo->prepare("SELECT u.*, r.role_name FROM users u JOIN roles r ON r.id=u.role_id WHERE username=? AND status='Active' LIMIT 1");
  $stmt->execute([trim($_POST['username'] ?? '')]); $u=$stmt->fetch();
  if($u && password_verify($_POST['password'] ?? '', $u['password_hash'])){unset($u['password_hash']); $_SESSION['user']=$u; log_action($pdo,'LOGIN','AUTH',$u['id'],'Successful login'); app_redirect('/index.php');}
  $error='Invalid username or password';
}
?><!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css"><title>Login</title></head><body><main class="container" style="max-width:460px;margin:7vh auto"><div class="panel"><h1>🏍 Nalinda Motors</h1><p class="muted">POS & Workshop Management Login</p><?php if($error): ?><div class="error"><?=e($error)?></div><?php endif; ?><form method="post"><label>Username</label><input name="username" autofocus required><label>Password</label><input name="password" type="password" required><br><br><button class="btn">Sign In</button></form><p class="muted">Default login: <b>admin</b> / <b>admin123</b></p></div></main></body></html>
