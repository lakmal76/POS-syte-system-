<?php require_once 'includes/header.php';
$stats=[
 'Today Sales'=>$pdo->query("SELECT COALESCE(SUM(grand_total),0) FROM sales_invoices WHERE DATE(created_at)=CURDATE()")->fetchColumn(),
 'Today Collection'=>$pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE DATE(paid_at)=CURDATE()")->fetchColumn(),
 'Open Jobs'=>$pdo->query("SELECT COUNT(*) FROM job_cards WHERE status NOT IN ('Invoiced','Cancelled')")->fetchColumn(),
 'Low Stock Items'=>$pdo->query("SELECT COUNT(*) FROM products p WHERE p.status='Active' AND (SELECT COALESCE(SUM(available_qty),0) FROM inventory_lots l WHERE l.product_id=p.id)<=p.reorder_level")->fetchColumn()
]; ?>
<section class="hero glass-panel"><h1>Nalinda Motors POS & Workshop Control Center</h1><p>Retail sales, inventory, job cards, barcode labels, reports and administration.</p></section>
<div class="grid cards"><?php foreach($stats as $k=>$v): ?><div class="card glass-panel"><div class="muted"><?=e($k)?></div><h2><?= is_numeric($v)? money($v):e($v) ?></h2></div><?php endforeach; ?></div>
<div class="grid two" style="margin-top:18px"><div class="glass-panel"><h3>Operational Shortcuts</h3><p class="actions"><a class="btn" href="pos/index.php">Open POS</a><a class="btn" href="jobcards/create.php">New Job Card</a><a class="btn" href="inventory/lots.php">Receive Stock</a><a class="btn" href="barcode/print_labels.php">Print Barcodes</a></p></div><div class="glass-panel"><h3>Installation Check</h3><p>Folder URL: <b><?=e(BASE_URL)?></b></p><p>Database: <b><?=e(DB_NAME)?></b></p><p class="muted">If this dashboard opens, Apache/PHP/MySQL connection is working.</p></div></div>
<?php require_once 'includes/footer.php'; ?>
