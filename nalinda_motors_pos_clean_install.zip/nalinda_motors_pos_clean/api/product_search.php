<?php require_once __DIR__.'/../includes/auth.php'; require_login(); header('Content-Type: application/json');
$q='%'.trim($_GET['q'] ?? '').'%';
$stmt=$pdo->prepare("SELECT p.*, COALESCE(SUM(l.available_qty),0) stock FROM products p LEFT JOIN inventory_lots l ON l.product_id=p.id WHERE p.status='Active' AND (p.product_name LIKE ? OR p.sku LIKE ? OR p.barcode_value LIKE ?) GROUP BY p.id ORDER BY p.product_name LIMIT 20");
$stmt->execute([$q,$q,$q]); echo json_encode($stmt->fetchAll());
