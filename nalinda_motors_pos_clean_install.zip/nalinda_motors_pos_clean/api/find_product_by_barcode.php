<?php require_once __DIR__.'/../includes/auth.php'; require_login(); header('Content-Type: application/json');
$barcode=trim($_GET['barcode'] ?? ''); if($barcode===''){echo json_encode(['success'=>false,'message'=>'Barcode required']); exit;}
$stmt=$pdo->prepare("SELECT p.*, COALESCE(SUM(l.available_qty),0) stock FROM products p LEFT JOIN inventory_lots l ON l.product_id=p.id WHERE p.status='Active' AND (p.barcode_value=? OR p.sku=?) GROUP BY p.id LIMIT 1");
$stmt->execute([$barcode,$barcode]); $p=$stmt->fetch();
echo json_encode($p?['success'=>true,'product'=>$p]:['success'=>false,'message'=>'Product not found']);
