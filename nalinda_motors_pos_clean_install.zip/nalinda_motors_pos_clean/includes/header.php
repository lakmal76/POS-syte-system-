<?php require_once __DIR__ . '/auth.php'; require_once __DIR__ . '/helpers.php'; require_login(); ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e(APP_NAME) ?></title><link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css"><script defer src="<?= BASE_URL ?>/assets/js/app.js"></script></head><body>
<nav class="topbar"><div class="brand">🏍 <?= e(SHOP_NAME) ?></div><button class="navtoggle" onclick="document.body.classList.toggle('navopen')">☰</button><div class="navlinks">
<a href="<?= BASE_URL ?>/index.php">Dashboard</a><a href="<?= BASE_URL ?>/pos/index.php">POS</a><a href="<?= BASE_URL ?>/jobcards/index.php">Job Cards</a>
<a href="<?= BASE_URL ?>/products/index.php">Products</a><a href="<?= BASE_URL ?>/inventory/lots.php">Stock Lots</a><a href="<?= BASE_URL ?>/inventory/adjustments.php">Adjust</a>
<a href="<?= BASE_URL ?>/barcode/print_labels.php">Barcodes</a><a href="<?= BASE_URL ?>/customers/index.php">Customers</a><a href="<?= BASE_URL ?>/mechanics/index.php">Mechanics</a>
<a href="<?= BASE_URL ?>/reports/dashboard.php">Reports</a><a href="<?= BASE_URL ?>/admin/users.php">Users</a><a href="<?= BASE_URL ?>/settings/index.php">Settings</a><a href="<?= BASE_URL ?>/auth/logout.php">Logout</a>
</div></nav><main class="container">
