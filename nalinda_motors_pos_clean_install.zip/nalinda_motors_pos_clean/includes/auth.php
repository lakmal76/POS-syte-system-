<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/db.php';
function is_logged_in(): bool { return isset($_SESSION['user']); }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): void { if (!is_logged_in()) { header('Location: ' . BASE_URL . '/auth/login.php'); exit; } }
function has_role(array $roles): bool { return in_array($_SESSION['user']['role_name'] ?? '', $roles, true); }
function require_role(array $roles): void { require_login(); if (!has_role($roles)) { http_response_code(403); exit('Access denied'); } }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8').'">'; }
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $ok = isset($_POST['csrf']) && hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf']);
        if (!$ok) { http_response_code(419); exit('Invalid CSRF token. Go back and reload the page.'); }
    }
}
