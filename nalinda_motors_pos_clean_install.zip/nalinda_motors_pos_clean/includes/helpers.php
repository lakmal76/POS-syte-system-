<?php
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function money($v): string { return 'LKR ' . number_format((float)$v, 2); }
function now_user_id(): ?int { return $_SESSION['user']['id'] ?? null; }
function app_redirect(string $path): void { header('Location: ' . BASE_URL . $path); exit; }
function next_number(PDO $pdo, string $prefix, string $table, string $field): string {
    $ym = date('Ym');
    $like = $prefix . '-' . $ym . '-%';
    $stmt = $pdo->prepare("SELECT $field FROM $table WHERE $field LIKE ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$like]);
    $last = $stmt->fetchColumn();
    $n = 1;
    if ($last && preg_match('/-(\d+)$/', $last, $m)) $n = ((int)$m[1]) + 1;
    return $prefix . '-' . $ym . '-' . str_pad((string)$n, 5, '0', STR_PAD_LEFT);
}
function log_action(PDO $pdo, string $action, string $module, $reference_id=null, string $details=''): void {
    try {
        $stmt=$pdo->prepare("INSERT INTO audit_logs(user_id, action, module, reference_id, details, ip_address) VALUES(?,?,?,?,?,?)");
        $stmt->execute([now_user_id(), $action, $module, $reference_id, $details, $_SERVER['REMOTE_ADDR'] ?? '']);
    } catch(Throwable $e) {}
}
function first_available_lot(PDO $pdo, int $product_id, float $qty): ?array {
    $stmt=$pdo->prepare("SELECT * FROM inventory_lots WHERE product_id=? AND available_qty>=? ORDER BY received_date ASC, id ASC LIMIT 1 FOR UPDATE");
    $stmt->execute([$product_id, $qty]);
    $lot=$stmt->fetch();
    return $lot ?: null;
}
