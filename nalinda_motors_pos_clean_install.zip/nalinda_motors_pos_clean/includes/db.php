<?php
require_once __DIR__ . '/config.php';
try {
    $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo '<h2>Database connection failed</h2>';
    echo '<p>Import <b>sql/full_install.sql</b> into phpMyAdmin and check <b>includes/config.php</b>.</p>';
    exit;
}
