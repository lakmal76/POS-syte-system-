<?php
// Nalinda Motors POS & Workshop - Clean Build
// WAMP/XAMPP default DB settings. Change only if your MySQL password is different.
define('APP_NAME', 'Nalinda Motors POS & Workshop');
define('SHOP_NAME', 'NALINDA MOTORS');
define('DB_HOST', 'localhost');
define('DB_NAME', 'nalinda_pos_workshop');
define('DB_USER', 'root');
define('DB_PASS', '');

function base_url(): string {
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $root = '/nalinda_motors_pos_clean';
    $pos = strpos($script, $root);
    if ($pos !== false) return $root;
    $parts = explode('/', trim($script, '/'));
    return isset($parts[0]) && $parts[0] !== '' ? '/' . $parts[0] : '';
}
define('BASE_URL', base_url());
