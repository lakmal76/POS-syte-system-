Clean package generated for Nalinda Motors Motorcycle POS & Workshop Management System.

Included modules:
- Secure login and roles
- Dashboard
- Product master
- Inventory receiving by lots
- Stock adjustments
- Barcode label print preview
- Retail POS with scanner-friendly barcode field
- Invoice print
- Job card creation, labor/parts billing, status workflow
- Workshop job-card-to-invoice conversion
- Customers and mechanics
- Reports, stock report, expenses, daily closing
- Admin user creation
- Settings

Folder name to use under WAMP: nalinda_motors_pos_clean
SQL file: sql/full_install.sql
Default login: admin / admin123
