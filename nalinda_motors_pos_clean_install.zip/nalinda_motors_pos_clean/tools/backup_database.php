<?php
// Simple backup instruction file. For production, run mysqldump from Windows Task Scheduler.
echo "Run in Command Prompt:\n\n";
echo "cd C:\\wamp64\\bin\\mysql\\mysql8.x.x\\bin\n";
echo "mysqldump -u root nalinda_pos_workshop > C:\\backup\\nalinda_pos_workshop.sql\n";
